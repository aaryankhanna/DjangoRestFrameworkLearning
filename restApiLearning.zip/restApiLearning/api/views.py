from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.renderers import JSONRenderer
from .models import Student
from .serializers import StudentSerializer
import io
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import ListModelMixin,CreateModelMixin,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin
from rest_framework.generics import RetrieveUpdateDestroyAPIView,ListCreateAPIView
from rest_framework import viewsets
# Create your views here.
# Just for get api alone
# def studentDetail(request):
#     stu=Student.objects.all()
#     serializer=StudentSerializer(stu,many=True)
#     json_data=JSONRenderer().render(serializer.data)
#     return HttpResponse(json_data,content_type='application/json')

# def studentDetail():
#     stu=Student.objects.all()
#     serializer=StudentSerializer(stu,many=True)
#     json_data=JSONRenderer().render(serializer.data)
#     return HttpResponse(json_data,content_type='application/json')



# @csrf_exempt
# def create_student(request):
#     if request.method=="POST":
#         json_data=request.body
#         stream=io.BytesIO(json_data)
#         pythonData=JSONParser().parse(stream)
#         serializer=StudentSerializer(data=pythonData)
#         if serializer.is_valid():
#             serializer.save()
#             res={'msg':'Data Created'}
#             jsondata=JSONRenderer().render(res)
#             return HttpResponse(jsondata,content_type='application/json')
        
    # elif request.method=="GET":
    #     json_data=request.body
    #     stream=io.BytesIO(json_data)
    #     pythonData=JSONParser().parse(stream)
    #     id=pythonData.get('id',None)
    #     if id is not None:
    #         stu=Student.objects.get(id=id)
    #         serializer=StudentSerializer(stu)
    #         jsondata=JSONRenderer().render(serializer.data)
    #         return HttpResponse(jsondata,content_type='application/json')
    #     else:
    #         return studentDetail()
            
#     elif request.method=="PUT":
#         json_data=request.body
#         stream=io.BytesIO(json_data)
#         pythonData=JSONParser().parse(stream)
#         id=pythonData.get('id')
#         stu=Student.objects.get(id=id)
#         serializer=StudentSerializer(stu,data=pythonData,partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             res={'msg':'Data updated'}
#             jsondata=JSONRenderer().render(res)
#             return HttpResponse(jsondata,content_type='application/json')
        
#     elif request.method=="DELETE":
#         json_data=request.body
#         stream=io.BytesIO(json_data)
#         pythonData=JSONParser().parse(stream)
#         id=pythonData.get('id')
#         stu=Student.objects.get(id=id)
#         stu.delete()
#         res={'msg':'Data Deleted          '}
#         jsondata=JSONRenderer().render(res)
#         return HttpResponse(jsondata,content_type='application/json')


# USING Function based API VIEW FOR CRUD FUNCTIONALITY

# @api_view(['GET', 'POST', 'PUT', 'DELETE'])
# def create_student(request,pk=None):
#     if request.method == "GET":
#         id = request.query_params.get('id') 
#         # or
#         id=pk
#         if id:
#             try:
#                 student = Student.objects.get(id=id)
#                 serializer = StudentSerializer(student)
#                 return Response(serializer.data)
#             except Student.DoesNotExist:
#                 return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)
#         else:
#             print("in else")
#             students = Student.objects.all()
#             serializer = StudentSerializer(students, many=True)
#             return Response(serializer.data)

#     elif request.method == "POST":
#         serializer = StudentSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             print(request.data)
#             return Response({"message": "Student created successfully"}, status=status.HTTP_201_CREATED)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     elif request.method == "PUT":
#         id = request.data.get('id')
#         # or
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for PUT request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)

#         serializer = StudentSerializer(student, data=request.data, partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response({"message": "Student updated successfully"}, status=status.HTTP_200_OK)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     elif request.method == "DELETE":
#         id = request.data.get('id')
#         # or
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for DELETE request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#             student.delete()
#             return Response({"message": "Student deleted successfully"}, status=status.HTTP_200_OK)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)



# USING CLASS Based API View 

# class StudentAPI(APIView):
#     def get(self,request,pk=None,format=None):
#         id = request.query_params.get('id') 
#         # or
#         id=pk
#         if id:
#             try:
#                 student = Student.objects.get(id=id)
#                 serializer = StudentSerializer(student)
#                 return Response(serializer.data)
#             except Student.DoesNotExist:
#                 return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)
#         else:
#             print("in else")
#             students = Student.objects.all()
#             serializer = StudentSerializer(students, many=True)
#             return Response(serializer.data)
        
        
#     def post(self,request,pk=None,format=None):
#         serializer = StudentSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             print(request.data)
#             return Response({"message": "Student created successfully"}, status=status.HTTP_201_CREATED)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        
#     def put(self,request,pk=None,format=None):
#         id = request.data.get('id')
#         # or
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for PUT request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)

#         serializer = StudentSerializer(student, data=request.data, partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response({"message": "Student updated successfully"}, status=status.HTTP_200_OK)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        
#     def delete(self,request,pk=None,format=None):
#         id = request.data.get('id')
#         # or
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for DELETE request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#             student.delete()
#             return Response({"message": "Student deleted successfully"}, status=status.HTTP_200_OK)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)



# Using Generic API view and Mixins

# class StudentList(GenericAPIView,ListModelMixin,CreateModelMixin):
#     queryset=Student.objects.all()
#     serializer_class=StudentSerializer
    
#     def get(self,request,*args, **kwargs):
#         return self.list(request,*args, **kwargs)
    
#     def post(self,request,*args, **kwargs):
#         return self.create(request,*args, **kwargs)


# class StudentReterieve(GenericAPIView,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin):
#     queryset=Student.objects.all()
#     serializer_class=StudentSerializer
    
#     def get(self,request,*args, **kwargs):
#         return self.retrieve(request,*args, **kwargs)
    
#     def put(self,request,*args, **kwargs):
#         return self.update(request,*args, **kwargs) 
    
#     def delete(self,request,*args, **kwargs):
#         return self.destroy(request,*args, **kwargs) 


# USING CONCRETE API VIEW

# class StudentRetrieve(RetrieveUpdateDestroyAPIView):
#     queryset=Student.objects.all()
#     serializer_class=StudentSerializer
    
# class StudentListCreate(ListCreateAPIView):
#     queryset=Student.objects.all()
#     serializer_class=StudentSerializer



# Using ViewSet

# class StudentViewSet(viewsets.ViewSet):
#     def list(self,request):
#         stu=Student.objects.all()
#         serializer=StudentSerializer(stu,many=True)
#         return Response(serializer.data)
    
#     def retrieve(self,request,pk=None):
#         id=pk
#         if id:
#             student = Student.objects.get(id=id)
#             serializer = StudentSerializer(student)
#             return Response(serializer.data)
        
#     def create(self,request):
#         serializer = StudentSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             print(request.data)
#             return Response({"message": "Student created successfully"}, status=status.HTTP_201_CREATED)
#     def update(self,request,pk):
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for PUT request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)

#         serializer = StudentSerializer(student, data=request.data, partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response({"message": "Student updated successfully"}, status=status.HTTP_200_OK)
        
#     def destroy(self,request,pk):
#         id=pk
#         if not id:
#             return Response({"message": "ID parameter is required for DELETE request"}, status=status.HTTP_400_BAD_REQUEST)
#         try:
#             student = Student.objects.get(id=id)
#             student.delete()
#             return Response({"message": "Student deleted successfully"}, status=status.HTTP_200_OK)
#         except Student.DoesNotExist:
#             return Response({"message": "Student not found"}, status=status.HTTP_404_NOT_FOUND)



# using Model View Set 


class StudentModelViewSet(viewsets.ModelViewSet):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer