
from django.contrib import admin
from django.urls import path,include
from api import views
from rest_framework.routers import DefaultRouter




# for viewSets
# router = DefaultRouter()
# router.register('stuAdd', views.StudentViewSet, basename='student')



# for modelViewSets
router = DefaultRouter()
router.register('stuAdd', views.StudentModelViewSet, basename='student')



urlpatterns = [
    path('admin/', admin.site.urls),
    # path('stuinfo/',views.studentDetail),
    
    # for Function Based API view
    # path('stuAdd/',views.create_student),
    # path('stuAdd/<int:pk>/',views.create_student),
    
    # for Class Based fAPI view
    
    # path('stuAdd/',views.StudentAPI.as_view()),
    # path('stuAdd/<int:pk>/',views.StudentAPI.as_view()),
    
    # for generic API and Mixins
    
    # path('stuAdd/',views.StudentList.as_view()),
    # path('stuAdd/<int:pk>/',views.StudentReterieve.as_view()),
    
    
    # for Concrete API View
    
#     path('stuAdd/',views.StudentListCreate.as_view()),
#     path('stuAdd/<int:pk>/',views.StudentRetrieve.as_view()),


    # for ViewSet 

    path('', include(router.urls)),
    
    # just for session authentication
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
    


]

