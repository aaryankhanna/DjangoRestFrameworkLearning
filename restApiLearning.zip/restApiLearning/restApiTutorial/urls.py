
from django.contrib import admin
from django.urls import path
from api import views
urlpatterns = [
    path('admin/', admin.site.urls),
    # path('stuinfo/',views.studentDetail),
    
    # for Function Based API view
    # path('stuAdd/',views.create_student),
    # path('stuAdd/<int:pk>/',views.create_student),
    
    # for Class Based fAPI view
    
    # path('stuAdd/',views.StudentAPI.as_view()),
    # path('stuAdd/<int:pk>/',views.StudentAPI.as_view()),
    
    # for generic API and Mixins
    
    path('stuAdd/',views.StudentList.as_view()),
    path('stuAdd/<int:pk>/',views.StudentReterieve.as_view()),
]

