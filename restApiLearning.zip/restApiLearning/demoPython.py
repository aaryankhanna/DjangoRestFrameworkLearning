import requests
import json
URL="http://127.0.0.1:8000/stuAdd/"



def getData(id=None):
    params = {'id': id} if id is not None else {}
    headers = {'content-Type': 'application/json'}
    r = requests.get(url=URL, headers=headers, params=params)
    data = r.json()
    print(data)
    

def postData():
    data = {
        'name': 'ABC',
        'roll': 7,
        'city': 'Himachal'
    }
    headers = {'content-Type': 'application/json'}
    r = requests.post(url=URL, headers=headers, json=data)
    data = r.json()
    print(data)

def updateData(id=None):
    data = {
        'id': id,
        'name': 'checkUpdation',
        'city': 'updatedCity'
    }
    headers = {'content-Type': 'application/json'}
    r = requests.put(url=URL, headers=headers, json=data)
    data = r.json()
    print(data)

def deleteData(id=None):
    data = {
        'id': id,
    }
    headers = {'content-Type': 'application/json'}
    r = requests.delete(url=URL, headers=headers, json=data)
    data = r.json()
    print(data)

    
    
getData(3)    
# updateData()
# postData()
# deleteData()